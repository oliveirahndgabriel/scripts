using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Weapon", menuName = "WeaponType")]
public class WeaponScriptable : ScriptableObject
{
    public new string name;

    public float damage, speed;

    //[Header("Turret Enemy")]
    public float attackRange, shootRate, shootCounter;
}
