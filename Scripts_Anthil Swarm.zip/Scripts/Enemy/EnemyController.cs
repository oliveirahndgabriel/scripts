using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    [SerializeField] EnemyScriptable enemyScript;

    [SerializeField] bool isChasing, canWalk, alreadyAttk, waitToChase = false;

    Vector3 target, startPoint;

    float targetDistance;

    PlayerController playerTarget;

    bool isFacingRight = true;

    private void Awake()
    {
        playerTarget = GameObject.Find("Player").GetComponent<PlayerController>();
    }

    // Start is called before the first frame update
    void Start()
    {
        startPoint = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        target = playerTarget.transform.position;

        targetDistance = Vector2.Distance(transform.position, target);

        if (canWalk)
        {
            EnemyMovementChase();
        }

        DamageCollider();
        RotatePlayer();
    }

    void EnemyMovementChase()
    {
        if (targetDistance < enemyScript.distanceToChase)
        {
            isChasing = true;

            if (isChasing && !waitToChase)
            {
                transform.position = Vector2.MoveTowards(transform.position, target, enemyScript.speed * Time.deltaTime);
            }
        }

    }

    void DamageCollider()
    {
        Collider2D[] otherCollision;
        otherCollision = Physics2D.OverlapCircleAll(transform.position, enemyScript.raio);

        foreach (Collider2D actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Player")
            {
                if (!alreadyAttk)
                {
                    alreadyAttk = true;

                    actualOther.gameObject.GetComponent<PlayerHealth>().TakeDamage(enemyScript.damage);

                    waitToChase = true;

                    StartCoroutine(FollowCounter());
                }

            }
        }
    }

    IEnumerator FollowCounter()
    {
        yield return new WaitForSeconds(enemyScript.waitToChase);

        waitToChase = false;

        alreadyAttk = false;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, enemyScript.raio);
    }

    void RotatePlayer()
    {
        if (target.x < transform.position.x && !isFacingRight)
        {
            Facing();
        }
        else if (target.x > transform.position.x && isFacingRight)
        {
            Facing();
        }
    }

    void Facing()
    {
        isFacingRight = !isFacingRight;
        transform.Rotate(0f, 180f, 0f);
    }
}
