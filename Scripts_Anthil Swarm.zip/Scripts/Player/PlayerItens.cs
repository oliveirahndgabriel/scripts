using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerItens : MonoBehaviour
{
    public int recoverAmount, oxygenAmount, ammoAmount;
    [SerializeField] float raio = 0.15f;
    UiManager uiManager;
    PlayerHealth playerHealth;

    private void Awake()
    {
        uiManager = FindObjectOfType<UiManager>().GetComponent<UiManager>();
        playerHealth = FindObjectOfType<PlayerHealth>().GetComponent<PlayerHealth>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        DetectCollisions();

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        uiManager.RecoverText.text = "x " + recoverAmount.ToString();
        uiManager.AmmoText.text = "x " + ammoAmount.ToString();
    }

    void DetectCollisions()
    {
        Collider2D[] otherCollision;
        otherCollision = Physics2D.OverlapCircleAll(transform.position, raio);

        foreach (Collider2D actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "PickUp")
            {
                Debug.Log("Press E to collect");

                if (Input.GetKeyDown(KeyCode.E))
                {
                    if(actualOther.gameObject.GetComponent<PickUps>().functionType == "Health")
                    {
                        RecoverHandler(actualOther.gameObject.GetComponent<PickUps>().recoverAmount);
                    }

                    if (actualOther.gameObject.GetComponent<PickUps>().functionType == "Oxygen")
                    {
                        OxygenHandler(actualOther.gameObject.GetComponent<PickUps>().oxygenAmount);
                    }

                    if (actualOther.gameObject.GetComponent<PickUps>().functionType == "Ammo")
                    {
                        AmmoHandler(actualOther.gameObject.GetComponent<PickUps>().ammoAmount);
                    }


                    Debug.Log("Item collected");

                    Destroy(actualOther.gameObject);
                }
            }
        }
    }

    void RecoverHandler(int amount)
    {
        recoverAmount += amount;
    }

    void OxygenHandler(int amount)
    {
        playerHealth.currentOxygen += amount;
    }

    void AmmoHandler(int amount)
    {
        ammoAmount += amount;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, raio);
    }
}

