using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookAtPoint : MonoBehaviour
{
    public static LookAtPoint instance;

    Vector3 mousePosition;
    Vector2 direction;

    [SerializeField] GameObject playerObject;
    [SerializeField] SpriteRenderer weaponSprite;
    bool isFacingRight = true;

    private void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

        direction = new Vector2(mousePosition.x - transform.position.x, mousePosition.y - transform.position.y);

        transform.right = direction;

        RotateWeapon();
    }

    void RotateWeapon()
    {
        if (direction.x >= 0 && !isFacingRight)
        {
            Facing();
            weaponSprite.flipY = false;

        }
        else if (direction.x < 0 && isFacingRight)
        {
            Facing();
            weaponSprite.flipY = true;
        }
    }

    void Facing()
    {
        isFacingRight = !isFacingRight;
        playerObject.transform.Rotate(0f, 180f, 0f);
    }
}
