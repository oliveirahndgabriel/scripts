using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerKeys : MonoBehaviour
{
    [SerializeField] List<string> keyListName = new List<string>();
    //string[] keyCode = new string[] {"keyRed", "keyBlue", "KeyGreen"};
    [SerializeField] float raio = 1f;
    UiManager uiManager;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        DetectCollisions();
    }

    void DetectCollisions()
    {
        Collider2D[] otherCollision;
        otherCollision = Physics2D.OverlapCircleAll(transform.position, raio);

        foreach (Collider2D actualOther in otherCollision)
        {
            var actualObject = actualOther.gameObject;

            if (actualObject.tag == "Door")
            {
                if (actualObject.GetComponent<DoorSystem>().isClosed && actualObject.GetComponent<DoorSystem>().needsKey == false)
                {
                    Debug.Log("Press E to open");

                    if (Input.GetKeyDown(KeyCode.E))
                    {
                        actualObject.GetComponent<DoorSystem>().OpenDoor();
                        Debug.Log("Door Opened");
                    }
                }
                else 
                {
                    if (Input.GetKeyDown(KeyCode.E))
                    {
                        actualObject.GetComponent<DoorSystem>().CloseDoor();
                        Debug.Log("Door Closed");
                    }
                }

                //opening doors that need keys
                if(actualObject.GetComponent<DoorSystem>().isClosed && actualObject.GetComponent<DoorSystem>().needsKey)
                {
                    Debug.Log("Press E to open the Key Door");

                    if (Input.GetKeyDown(KeyCode.E) && keyListName.Contains(actualObject.GetComponent<DoorSystem>().doorType))
                    {
                        actualObject.GetComponent<DoorSystem>().OpenDoor();
                        Debug.Log("Door Opened");
                    }
                    else
                    {
                        Debug.Log("You do not have the Key!");
                    }
                }
            }

            if(actualObject.tag == "Key")
            {
                Debug.Log("Press E to pick the Key");

                if (Input.GetKeyDown(KeyCode.E))
                {
                    keyListName.Add(actualObject.GetComponent<PickUps>().keyName);
                    Debug.Log(actualObject.name + " Collected");

                    Destroy(actualObject);
                }
            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, raio);
    }
}
