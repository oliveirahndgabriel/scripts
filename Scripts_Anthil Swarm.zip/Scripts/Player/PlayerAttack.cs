using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    [SerializeField] WeaponScriptable weaponScript;

    // float attackCounter, tpCounter;
    //[SerializeField] float attackRate = 0.3f, tpRate = 0.5f;

    //[SerializeField] float attackRange;
    [SerializeField] LayerMask enemyLayer;

    //[SerializeField] GameObject fireBall, bullet;

    [SerializeField] float playerDamage;
    [SerializeField] Transform shootPoint;

    [SerializeField] LineRenderer lineRenderer;
    PlayerItens playerItens;

    [SerializeField] bool isAuto, isProjectile, haveAmmo, isMelee;

    int actualAmmo;

    LookAtPoint lookPoint;

    private void Awake()
    {
        lookPoint = FindObjectOfType<LookAtPoint>().GetComponent<LookAtPoint>();
        playerItens = GetComponent<PlayerItens>();
    }

    // Start is called before the first frame update
    void Start()
    {
        // attackCounter = attackRate;
    }

    // Update is called once per frame
    void Update()
    {
        if(actualAmmo > 0)
        {
            haveAmmo = true;
            {
                if (Input.GetKeyDown(KeyCode.Mouse0) && haveAmmo)
                {
                    StartCoroutine(Shoot());
                }
            }
        }
        else if(actualAmmo <= 0)
        {

           // Debug.Log("Out of Ammo");
            haveAmmo = false;
        }

        Reload();
        MeleeAttack();
    }

    //avaliar essa coroutina
    IEnumerator Shoot()
    {
        RaycastHit2D hitInfo = Physics2D.Raycast(shootPoint.position, shootPoint.right);

        if (hitInfo)
        {
            EnemyHealth enemy = hitInfo.transform.GetComponent<EnemyHealth>();
            if (enemy != null)
            {
                enemy.EnemyTakeDamage(10f);
                Debug.Log("Toma barata");
            }

            lineRenderer.SetPosition(0, shootPoint.position);
            lineRenderer.SetPosition(1, hitInfo.point);
        }
        else
        {
            lineRenderer.SetPosition(0, shootPoint.position);
            lineRenderer.SetPosition(1, shootPoint.position + shootPoint.right * 100);
        }

        lineRenderer.enabled = true;
        actualAmmo--;

        yield return new WaitForSeconds(0.02f);

        lineRenderer.enabled = false;
    }

    void Reload()
    {
        if(playerItens.ammoAmount > 0)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                actualAmmo += playerItens.ammoAmount;
                Debug.Log("Reloaded");
            }
        }
        else
        {
            //Debug.Log("Do not have storage ammo");
        }
    }



    void ProjectileAttack()
    {
        if (isProjectile)
        {
            if (Input.GetKey(KeyCode.Mouse0))
            {
                Debug.Log("Projectile Shoot");
                /*if (weaponScript.shootCounter <= 0)
                {
                    Instantiate(bullet, lookPoint.transform.position, lookPoint.transform.rotation);

                    weaponScript.shootCounter = weaponScript.shootRate;
                }*/
            }
            //weaponScript.shootCounter -= Time.deltaTime;
        }
    }

    void MeleeAttack()
    {
        if (isMelee)
        {
            if (Input.GetKey(KeyCode.F))
            {
                Debug.Log("Melee attack");
                if (weaponScript.shootCounter <= 0)
                {
                    Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, weaponScript.attackRange, enemyLayer);

                    foreach (Collider2D enemy in hitEnemies)
                    {
                        Debug.Log(enemy.name + " was hit");
                        enemy.GetComponent<EnemyHealth>().EnemyTakeDamage(weaponScript.damage);
                    }
                    
                    weaponScript.shootCounter = weaponScript.shootRate;
                }
            }
            weaponScript.shootCounter -= Time.deltaTime;
        }
    }


    private void OnDrawGizmos()
    {
        if (isMelee)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, weaponScript.attackRange);
        }
    }
}

   

