using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public float currentHealth, maxHealth = 100f, currentOxygen, maxOxygem = 100f, immortalDef = 9999f;

    public bool isDead, isImmortal;

    [SerializeField] GameObject immortalGlobe;

    PlayerItens playerItens;
    UiManager uiManager;

    private void Awake()
    {
        uiManager = FindObjectOfType<UiManager>().GetComponent<UiManager>();
        playerItens = GetComponent<PlayerItens>();
    }

    // Start is called before the first frame update
    void Start()
    {
        isDead = false;

        currentHealth = maxHealth;

        uiManager.healthSlider.maxValue = maxHealth;
        uiManager.OxygenText.text = currentOxygen + " %";
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X))
        {
            isImmortal = true;
            immortalDef = 9999f;

        }
        IsImmortal();
    }

    private void FixedUpdate()
    {
        uiManager.healthSlider.value = currentHealth;
        uiManager.HealthText.text = currentHealth.ToString("f0") + " HP";

        uiManager.OxygenText.text = currentOxygen.ToString("f2") + " %";

        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            currentHealth += playerItens.recoverAmount;
            playerItens.recoverAmount -= playerItens.recoverAmount;
        }
    }

    public void TakeDamage(float damage)
    {
        if (!isImmortal)
        {
            currentHealth -= damage;
        }
        else if (isImmortal)
        {
            immortalDef -= damage;
        }

        if (currentHealth <= 0)
        {
            isDead = true;

            Debug.Log(gameObject + " is dead");

            Destroy(this.gameObject);
        }
    }

    public void TakeDamageContinuos(float damage)
    {
        if(currentOxygen > 0)
        {
            currentOxygen -= damage * Time.deltaTime;
        }
        else if(currentOxygen <= 0)
        {
            currentHealth -= 5f * damage * Time.deltaTime;
        }

        if (currentHealth <= 0)
        {
            isDead = true;

            Debug.Log(gameObject + " is RADIOACTIVE");

            Destroy(this.gameObject);
        }
    }

    void IsImmortal()
    {
        if (isImmortal)
        {
            immortalGlobe.gameObject.SetActive(true);

            Debug.Log("is immortal");
        }

        if (immortalDef < 9999f)
        {
            isImmortal = false;
            immortalGlobe.gameObject.SetActive(false);
            // Debug.Log("is not immortal");
        }
    }
}
