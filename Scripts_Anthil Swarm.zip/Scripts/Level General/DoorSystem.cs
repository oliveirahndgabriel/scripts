using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorSystem : MonoBehaviour
{
    public bool isClosed, needsKey;
    public string doorType;

    Collider2D doorCollider;

    // Start is called before the first frame update
    void Start()
    {
        doorCollider = GetComponent<Collider2D>();
        doorCollider.isTrigger = false;
        isClosed = true;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        
    }

    public void OpenDoor()
    {
        doorCollider.isTrigger = true;
        isClosed = false;
    }

    public void CloseDoor()
    {
        doorCollider.isTrigger = false;
        isClosed = true;
    }
}
