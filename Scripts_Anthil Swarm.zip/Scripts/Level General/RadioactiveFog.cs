using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RadioactiveFog : MonoBehaviour
{
    PlayerHealth playerHealth;

    private void Awake()
    {
        playerHealth = FindObjectOfType<PlayerHealth>().GetComponent<PlayerHealth>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        DetectCollisions();
    }

    void DetectCollisions()
    {
        Collider2D[] otherCollision;
        otherCollision = Physics2D.OverlapBoxAll(transform.position, transform.localScale, 0); 

        foreach (Collider2D actualOther in otherCollision)
        {
            var actualObject = actualOther.gameObject;

            if (actualObject.tag == "Player")
            {
                playerHealth.TakeDamageContinuos(0.5f);

                Debug.Log(" RADIOACTIVE ");
            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireCube(transform.position, transform.localScale);
    }

}
