using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUps : MonoBehaviour
{
    
    public int recoverAmount, oxygenAmount, ammoAmount;
    public string functionType;

    public string keyName;


    private void Start()
    {
        if(gameObject.tag == "Key")
        {
            keyName = gameObject.name;
        }
    }
}


