using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    UiManager uiManager;
    PlayerHealth playerHealth;
    [SerializeField] GameObject ingameMenu;

    private void Awake()
    {
        instance = this;

        uiManager = FindObjectOfType<UiManager>().GetComponent<UiManager>();

        playerHealth = FindObjectOfType<PlayerHealth>().GetComponent<PlayerHealth>();

        ingameMenu.SetActive(false);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        OpenInGameMenu();

    }

    private void FixedUpdate()
    {
        GameOver();

    }

    void GameOver()
    {
        if (playerHealth.isDead)
        {
            uiManager.gameOverPanel.SetActive(true);

            StartCoroutine(RestartScene());
        }
    }

    IEnumerator RestartScene()
    {
        yield return new WaitForSeconds(5);

        SceneManager.GetActiveScene();
    }

    void OpenInGameMenu()
    {
        if (!playerHealth.isDead && Input.GetKeyDown(KeyCode.Escape))
        {
            ingameMenu.SetActive(true);
        }
    }
}
