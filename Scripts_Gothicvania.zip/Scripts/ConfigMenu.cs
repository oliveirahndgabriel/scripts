﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Audio;

public class ConfigMenu : MonoBehaviour
{
    [SerializeField] GameObject configMenu; 

    [SerializeField] Slider volumeSlider;
    [SerializeField] float currentVolume;
    [SerializeField] AudioMixer mixer;


    // Start is called before the first frame update
    void Start()
    {
        volumeSlider.value = PlayerPrefs.GetFloat("MusicVolume", 0.75f);

        Fullscreen();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void BackMainMenu()
    {
        configMenu.SetActive(false);
    }

    public void VolumeGame(float volumeSlider)
    {
        mixer.SetFloat("Music", Mathf.Log10(volumeSlider) * 20);
        PlayerPrefs.SetFloat("MusicVolume", volumeSlider);
    }

    public void Fullscreen()
    {
        Screen.fullScreen = !Screen.fullScreen;
    }

    public void ChangeResolution()
    {
        Screen.SetResolution(1920, 1080, true);
    }
}
