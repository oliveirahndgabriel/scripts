﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public static PlayerController instance;

    Rigidbody2D playerRB;
    Animator playerAnim;

    [Header(" Player Movement")]
    [Space]
    [SerializeField] float moveSpeed = 10;
    [SerializeField] float jumpForce = 10;
    float horizontalInput;
    bool isFacingRight = true;
    bool isJumping = false;

    float jumpCounter;
    [SerializeField] float jumpTime;

    bool isGrounded;
    [SerializeField] Transform groundCheck;
    [SerializeField] float radiusCheck;
    [SerializeField] LayerMask whatIsGround;

    [Header(" Player Attack")]
    [Space]
    [SerializeField] Transform attackPoint;
    [SerializeField] float attackRange = 0.5f;
    [SerializeField] LayerMask enemyLayer;
    [SerializeField] float playerDamage = 15;

    private void Awake()
    {
        instance = this;

        playerRB = GetComponent<Rigidbody2D>();
        playerAnim = GetComponent<Animator>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        MoveInput();
        Attack();
    }

    private void FixedUpdate()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        playerRB.velocity = new Vector2(horizontalInput * moveSpeed, playerRB.velocity.y);

        if(horizontalInput > 0.01f && isGrounded && !isJumping || horizontalInput < -0.01f && isGrounded && !isJumping)
        {
            playerAnim.SetFloat("isRun", Mathf.Abs(2f));
        }
        else
        {
            playerAnim.SetFloat("isRun", Mathf.Abs(0f));
        }
    }

    void MoveInput()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, radiusCheck, whatIsGround);

        if (Input.GetKeyDown(KeyCode.Space) && isGrounded == true)
        {
            isJumping = true;
            jumpCounter = jumpTime;
            playerRB.velocity = Vector2.up * jumpForce;

            playerAnim.SetBool("isJumping", true);
        }

        if (Input.GetKey(KeyCode.Space) && isJumping == true)
        {
            if(jumpCounter > 0)
            {
                playerRB.velocity = Vector2.up * jumpForce;
                jumpCounter -= Time.deltaTime;
                playerAnim.SetBool("isJumping", true);
            }
            else
            {
                isJumping = false;
            }
        }

        if (Input.GetKeyUp(KeyCode.Space))
        {
            isJumping = false;
            
        }

        if (isGrounded)
        {
            playerAnim.SetBool("isJumping", false);
        }

        RotatePlayer();
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(groundCheck.position, radiusCheck);

        Gizmos.DrawWireSphere(attackPoint.position, radiusCheck);
    }

    void RotatePlayer()
    {
        if (horizontalInput > 0 && !isFacingRight)
        {
            Facing();
        }
        else if (horizontalInput < 0 && isFacingRight)
        {
            Facing();
        }
    }

    void Facing()
    {
        isFacingRight = !isFacingRight;
        transform.Rotate(0f, 180f, 0f);
    }

    void Attack()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            playerAnim.SetTrigger("isAttacking");

            Collider2D[] hiEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayer);

            foreach(Collider2D enemy in hiEnemies)
            {
                Debug.Log(enemy.name + " was hit");
                enemy.GetComponent<Enemy>().EnemyTakeDamage(playerDamage);
            }
        }
    }

    
}
