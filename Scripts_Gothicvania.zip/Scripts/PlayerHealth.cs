﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] float currentHealth, maxHealth = 100f;

    [SerializeField] Slider healthSlider;

    public bool isDead = false;

    [SerializeField] GameObject endGame;

    // Start is called before the first frame update
    void Start()
    {
        isDead = false;

        currentHealth = maxHealth;

        healthSlider.maxValue = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;

        healthSlider.value = currentHealth;

        if (currentHealth < 0)
        {
            Destroy(gameObject);

            isDead = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "DeadZone")
        {
            isDead = true;
        }

        if(collision.gameObject.tag == "Game Over")
        {
            endGame.SetActive(true);

            GameManager.instance.Restart();
        }
    }
}
