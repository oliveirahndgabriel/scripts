﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] Animator enemyAnim;
    Rigidbody2D enemyRB;

    [SerializeField] bool isPatrolling, isRunning, isLooking;

    [SerializeField] float enemyDamage = 15f;

    float enemyCurrentHealth;
    [SerializeField] float enemyMaxHealth = 45f;

    [SerializeField] float enemySpeed = 0.5f;
    bool moveRight;
    [SerializeField] Transform pointA, pointB;
    [SerializeField] SpriteRenderer sprite;

    PlayerHealth player;

    Transform target;

    [SerializeField] GameObject burningGhoul;
    [SerializeField] Transform pointToSpawn;

    [SerializeField] GameObject deathEffect;

    private void Awake()
    {
        enemyRB = GetComponent<Rigidbody2D>();

        player = FindObjectOfType<PlayerHealth>().GetComponent<PlayerHealth>();

        target = FindObjectOfType<PlayerController>().GetComponent<Transform>();
    }

    // Start is called before the first frame update
    void Start()
    {
        enemyCurrentHealth = enemyMaxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        EnemyMovement();

        Patrol();

        Run();
    }
    void EnemyMovement()
    {
        if (!isLooking)
        {
            if (moveRight)
            {
                enemyRB.velocity = new Vector2(enemySpeed, enemyRB.velocity.y);
                sprite.flipX = true;
            }
            if (!moveRight)
            {
                enemyRB.velocity = new Vector2(-enemySpeed, enemyRB.velocity.y);
                sprite.flipX = false;
            }
        }
        else
        {
            Look();
        }
        
    }

    void Patrol()
    {
        if (isPatrolling)
        {
            if (transform.position.x <= pointA.position.x)
            {
                moveRight = true;
            }
            if (transform.position.x >= pointB.position.x)
            {
                moveRight = false;
            }
        }
    }

    void Run()
    {
        if (isRunning)
        {
            if (transform.position.x <= target.position.x)
            {
                moveRight = true;
            }
            if (transform.position.x >= target.position.x)
            {
                moveRight = false;
            }
        }
    }

    void Look()
    {
        if (transform.position.x <= target.position.x)
        {
            sprite.flipX = false;
        }
        if (transform.position.x >= target.position.x)
        {
            sprite.flipX = true;
        }
    }

    public void EnemyTakeDamage(float damage)
    {
        enemyCurrentHealth -= damage;
        enemyAnim.SetTrigger("isEnemyHurt");

        if (isLooking)
        {
            enemyAnim.SetBool("startPower", true);

            StartCoroutine(GhoulSpawnCo());
        }

        if(enemyCurrentHealth <= 0)
        {
            Debug.Log(gameObject.name + " was killed");
            enemyAnim.SetBool("isEnemyDead", true);

            Instantiate(deathEffect, transform.position, transform.rotation);

            Destroy(this.gameObject, 1.1f);
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag == "Player")
        {
            if(player != null)
            {
                player.TakeDamage(enemyDamage);
                Debug.Log("the player take " + enemyDamage + " of damage");
            }
        }
    }

    void GhoulSpawn()
    {
        Instantiate(burningGhoul, pointToSpawn.position, pointToSpawn.rotation);

        Destroy(gameObject, 2f);
    }

    IEnumerator GhoulSpawnCo()
    {
        yield return new WaitForSeconds(7f);

        GhoulSpawn();
    }
}
