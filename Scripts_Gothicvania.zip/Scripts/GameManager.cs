﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public bool isPaused;

    [SerializeField] GameObject menuInGame;

    [SerializeField] string mainMenu;

    [SerializeField] GameObject config, gameOver;

    [SerializeField] PlayerHealth playerHealth;

    private void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        PauseGame();

        GameOver();
    }

    public void PauseGame()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && !isPaused)
        {
            Time.timeScale = 0f;

            menuInGame.SetActive(true);

            isPaused = true;
        }

        else if (Input.GetKeyDown(KeyCode.Escape) && isPaused)
        {
            Time.timeScale = 1f;

            menuInGame.SetActive(false);

            isPaused = false;
        }
    }

    public void Resume()
    {
        Time.timeScale = 1f;

        menuInGame.SetActive(false);

        isPaused = false;
    }

    public void MainMenu()
    {
        SceneManager.LoadScene(mainMenu);

        Time.timeScale = 1f;
    }

    public void ConfigInGame()
    {
        config.SetActive(true);
    }

    void GameOver()
    {
        if(playerHealth.isDead == true)
        {
            gameOver.SetActive(true);

            StartCoroutine(RestartCO());
        }
    }

    IEnumerator RestartCO()
    {
        yield return new WaitForSeconds(5f);

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void Restart()
    {
        StartCoroutine(RestartCO());
    }
   


}
