using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody playerRB;

    float horizontalInput, verticalInput;
    public float moveSpeed = 5f;

    Camera mainCam;

    public bool cantMove, redCard, blueCard;

    private void Awake()
    {
        playerRB = GetComponent<Rigidbody>();
        mainCam = FindObjectOfType<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        MovementInput();

        LookInput();
    }

    private void FixedUpdate()
    {
        MovementUpdate();
    }

    void MovementInput()
    {
        if (!GameManager.instance.isPaused)
        {
            horizontalInput = Input.GetAxisRaw("Horizontal");
            verticalInput = Input.GetAxisRaw("Vertical");
        }
    }

    void LookInput()
    {
        if (!GameManager.instance.isPaused)
        {
            Ray cameraRay = mainCam.ScreenPointToRay(Input.mousePosition);
            Plane groundPlane = new Plane(Vector3.up, Vector3.zero);
            float rayLength;

            if (groundPlane.Raycast(cameraRay, out rayLength))
            {
                Vector3 pointToLook = cameraRay.GetPoint(rayLength);
                Debug.DrawLine(cameraRay.origin, pointToLook, Color.blue);

                transform.LookAt(new Vector3(pointToLook.x, transform.position.y, pointToLook.z));
            }
        }
    }

    void MovementUpdate()
    {
        if (cantMove == false)
        {
            playerRB.velocity = new Vector3(moveSpeed * horizontalInput, 0 , moveSpeed * verticalInput);
        }
    }

}

