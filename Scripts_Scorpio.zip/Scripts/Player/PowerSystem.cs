using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerSystem : MonoBehaviour
{
    [SerializeField] int powerCharge, powerMaximum, regenBoost;

    PlayerShoot playerShoot;
    PlayerHealth playerHealth;

    UIManager uiManager;


    private void Awake()
    {
        playerShoot = GetComponent<PlayerShoot>();
        playerHealth = GetComponent<PlayerHealth>();

        uiManager = FindObjectOfType<UIManager>().GetComponent<UIManager>();
    }

    private void FixedUpdate()
    {
        UsePower();

        if(powerCharge >= powerMaximum)
        {
            powerCharge = powerMaximum;
        }

        uiManager.ammoText.text = powerCharge.ToString();
    }

    public void PowerController(int powerAmount)
    {
        powerCharge += powerAmount;
    }

    public void UsePower()
    {
        if(Input.GetKeyDown(KeyCode.X) && powerCharge >= 1)
        {
            LifeRegen();
            powerCharge -= 1;
            Debug.Log("Can use life boost");
        }

        if(Input.GetKeyDown(KeyCode.Q) && powerCharge >= 2)
        {
            PowerShield();
            powerCharge -= 2;
            Debug.Log("Can use shield");
        }

        if (Input.GetKeyDown(KeyCode.E) && powerCharge >= 3)
        {
            PowerTripleShot();
            powerCharge -= 3;
            Debug.Log("Can use triple shot");
        }

        if (Input.GetKeyDown(KeyCode.R) && powerCharge >= 5)
        {
            PowerBFG();
            powerCharge -= 5;
            Debug.Log("Can use BFG");
        }
    }

    public void LifeRegen()
    {
        AudioManager.instance.sfxPlay(6);

        playerHealth.LifeRegenBoost(regenBoost);
    }

    public void PowerShield()
    {
        AudioManager.instance.sfxPlay(4);


        playerHealth.isImmortal = true;
    }

    public void PowerTripleShot()
    {
        playerShoot.tripleShot = true;
    }

    public void PowerBFG()
    {
        playerShoot.BFGshot = true;
    }
}
