using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour
{
    [SerializeField] GameObject bulletPrefab, tripleBulletPrefab, BFGshotPrefab;
    [SerializeField] Transform shootPoint, BFGPoint;

    float fireCounter, tripleShotCounter;
    [SerializeField] float fireRate, tripleShotRate;

    public bool tripleShot, BFGshot;

    private void Start()
    {
        fireCounter = fireRate;
        tripleShotCounter = tripleShotRate;

    }

    // Update is called once per frame
    void Update()
    {
        BulletShoot();
    }

    void BulletShoot()
    {
        //shooting normal
        if (Input.GetKey(KeyCode.Mouse0) && !GameManager.instance.isPaused && !tripleShot)
        {
            if(fireCounter <= 0)
            {
                AudioManager.instance.sfxPlay(0);

                Instantiate(bulletPrefab, shootPoint.position, shootPoint.transform.rotation);
                fireCounter = fireRate;
            }
        }

        //shooting tripleshot
        if (Input.GetKey(KeyCode.Mouse0) && !GameManager.instance.isPaused && tripleShot)
        {
            if (fireCounter <= 0)
            {
                AudioManager.instance.sfxPlay(0);
                AudioManager.instance.sfxPlay(0);
                AudioManager.instance.sfxPlay(0);

                Instantiate(tripleBulletPrefab, shootPoint.position, shootPoint.transform.rotation);
                fireRate = 0.12f;
                fireCounter = fireRate;

            }
        }

        if (tripleShotCounter <= 0)
        {
            tripleShotCounter = tripleShotRate;
            tripleShot = false;
        }

        tripleShotCounter -= Time.deltaTime;
        fireCounter -= Time.deltaTime;


        //shooting BFGshot
        if (Input.GetKey(KeyCode.Mouse0) && !GameManager.instance.isPaused && BFGshot)
        {
            AudioManager.instance.sfxPlay(3);

            Instantiate(BFGshotPrefab, BFGPoint.position, BFGPoint.transform.rotation);

            BFGshot = false;

        }
    }

    
}
