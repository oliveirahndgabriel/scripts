using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] float bulletSpeed, destroyCounter, destroyRate;
    [SerializeField] GameObject particleSplash;

    [SerializeField] int damage;
    [SerializeField] bool isBFG, isHolder;

    private void Start()
    {
        destroyCounter = destroyRate;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.forward * bulletSpeed * Time.deltaTime);

        if (isHolder)
        {
            AutoDestroy();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        Instantiate(particleSplash, transform.position, transform.rotation);

        if(other.gameObject.tag == "Enemy")
        {
            Debug.Log("Damage to " + other.name);

            other.gameObject.GetComponent<EnemyHealth>().TakeDamage(damage);
        }

        if (isBFG)
        {
            if (other.gameObject.tag != "Enemy" && other.gameObject.tag != "PickUps")
            {
                AudioManager.instance.sfxPlay(5);

                Destroy(gameObject, 0.05f);
            }
        }
        else
        {
            Destroy(gameObject, 0.05f);
        }
    }

    void AutoDestroy()
    {
        if(destroyCounter <= 0)
        {
            Destroy(gameObject);
        }

        destroyCounter -= Time.deltaTime;
    }


}
