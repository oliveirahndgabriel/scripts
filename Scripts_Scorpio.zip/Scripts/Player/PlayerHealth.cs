using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public int currentHealth, maxHealth = 15;

    UIManager uiManager;

    public bool isImmortal;

    float immortalCounter;
    [SerializeField] float immortalRate = 5;

    [SerializeField] GameObject immortalGlobe;

    private void Awake()
    {
        uiManager = FindObjectOfType<UIManager>().GetComponent<UIManager>();

    }

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
        immortalCounter = immortalRate;

        uiManager.healthSlider.maxValue = maxHealth;

    }

    // Update is called once per frame
    void Update()
    {
        if(currentHealth <= 0)
        {
            Debug.Log(gameObject.name + " is dead");

            GameManager itsOver = FindObjectOfType<GameManager>().GetComponent<GameManager>();
            itsOver.isGameOver = true;

            Destroy(gameObject);
        }
    }

    private void FixedUpdate()
    {
        if (isImmortal)
        {
            immortalGlobe.gameObject.SetActive(true);

            if(immortalCounter <= 0)
            {
                immortalCounter = immortalRate;
                isImmortal = false;
                immortalGlobe.gameObject.SetActive(false);
                Debug.Log("is imortal");
            }

            immortalCounter -= Time.deltaTime;
        }

        uiManager.healthSlider.value = currentHealth;
        uiManager.healthText.text = currentHealth.ToString() + " HP";
        uiManager.healthSlider.maxValue = maxHealth;

        if(currentHealth >= maxHealth)
        {
            currentHealth = maxHealth;
        }
    }

    public void TakeDamage(int damageTaken)
    {
        if (!isImmortal)
        {
            currentHealth -= damageTaken;
        }
    }

    public void LifeRegenBoost(int boostAmount)
    {
        currentHealth += boostAmount;
    }

}
