using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUpCards : MonoBehaviour
{
    float raio = 1f;

    [SerializeField] bool redCard, blueCard;
    bool alreadyCollected;

    // Update is called once per frame
    void Update()
    {
        DetectCollisions();
    }

    void DetectCollisions()
    {
        Collider[] otherCollision;
        otherCollision = Physics.OverlapSphere(transform.position, raio);

        foreach (Collider actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Player")
            {
                if (redCard && !alreadyCollected)
                {
                    UIManager.instance.redCard.SetActive(true);

                    actualOther.gameObject.GetComponent<PlayerController>().redCard = true;

                    Debug.Log("Red Card collected");

                    alreadyCollected = true;

                    Destroy(gameObject);
                }

                if (blueCard && !alreadyCollected)
                {
                    UIManager.instance.blueCard.SetActive(true);

                    actualOther.gameObject.GetComponent<PlayerController>().blueCard = true;

                    Debug.Log("Blue Card collected");

                    alreadyCollected = true;

                    Destroy(gameObject);
                }

            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, raio);
    }
}
