using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUpBuff : MonoBehaviour
{
    float raio = 1f;

    [SerializeField] bool buffSpeed, buffHealth;
    bool alreadyCollected;

    // Update is called once per frame
    void Update()
    {
        DetectCollisions();
    }

    void DetectCollisions()
    {
        Collider[] otherCollision;
        otherCollision = Physics.OverlapSphere(transform.position, raio);

        foreach (Collider actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Player")
            {
                AudioManager.instance.sfxPlay(1);


                if (buffHealth && !alreadyCollected)
                {
                    UIManager.instance.buffHealth.SetActive(true);

                    actualOther.gameObject.GetComponent<PlayerHealth>().maxHealth += 5;
                    actualOther.gameObject.GetComponent<PlayerHealth>().currentHealth += 5;

                    Debug.Log("Health Buff collected");

                    alreadyCollected = true;

                    Destroy(gameObject);
                }

                if (buffSpeed && !alreadyCollected)
                {
                    UIManager.instance.buffSpeed.SetActive(true);

                    actualOther.gameObject.GetComponent<PlayerController>().moveSpeed += 0.5f;

                    Debug.Log("Speed Buff collected");

                    alreadyCollected = true;

                    Destroy(gameObject);
                }

            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, raio);
    }
}
