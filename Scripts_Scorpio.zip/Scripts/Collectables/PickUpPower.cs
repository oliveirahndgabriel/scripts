using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUpPower : MonoBehaviour
{
    float raio = 1f;
    [SerializeField] int powerAmount;

    // Update is called once per frame
    void Update()
    {
        DetectCollisions();
    }

    void DetectCollisions()
    {
        Collider[] otherCollision;
        otherCollision = Physics.OverlapSphere(transform.position, raio);

        foreach (Collider actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Player")
            {
                actualOther.gameObject.GetComponent<PowerSystem>().PowerController(powerAmount);

                Debug.Log("Power Up collected");

                Destroy(gameObject);
            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, raio);
    }
}
