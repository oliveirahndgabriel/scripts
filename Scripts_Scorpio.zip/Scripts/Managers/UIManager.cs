using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager instance;

    public Slider healthSlider, bossHealthSlider;

    public Text ammoText, healthText;

    public GameObject pauseScreen, redCard, blueCard, buffHealth, buffSpeed;

    [SerializeField] Image blackscreen;
    float fadeSpeed = 1.5f;

    private void Awake()
    {
        instance = this;
    }

    private void FixedUpdate()
    {
        FadeBlackscreen();
    }

    void FadeBlackscreen()
    {
        if (!GameManager.instance.levelEnding)
        {
            blackscreen.color = new Color(blackscreen.color.r, blackscreen.color.g, blackscreen.color.b, Mathf.MoveTowards(blackscreen.color.a, 0f, fadeSpeed * Time.deltaTime));
        }
        else
        {
            blackscreen.color = new Color(blackscreen.color.r, blackscreen.color.g, blackscreen.color.b, Mathf.MoveTowards(blackscreen.color.a, 1f, fadeSpeed * Time.deltaTime));
        }
    }
}
