using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance;

    [SerializeField] AudioSource[] bgm;
    [SerializeField] AudioSource[] sfx;

    public AudioSource footSteps;

    private void Awake()
    {
        instance = this;
    }

    public void BgmStop(int bgmNumber)
    {
        bgm[bgmNumber].Stop();
    }

    public void BgmPause(int bgmNumber)
    {
        bgm[bgmNumber].Pause();
    }

    public void BgmUnpause(int bgmNumber)
    {
        bgm[bgmNumber].UnPause();
    }

    public void sfxPlay(int sfxNumber)
    {
        sfx[sfxNumber].Stop();
        sfx[sfxNumber].Play();
    }

    public void sfxStop(int sfxNumber)
    {
        sfx[sfxNumber].Stop();
    }
}
