using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    float waitToLoadScene = 5f;

    [HideInInspector] public bool isPaused = false;
    [SerializeField] GameObject pauseScreen, gameOver;

    [HideInInspector] public bool levelEnding, isGameOver, isBossDefeated;

    private void Awake()
    {
        instance = this;

        isPaused = false;
    }

    // Start is called before the first frame update
    void Start()
    {
        //Cursor.lockState = CursorLockMode.Locked;
        //Cursor.visible = false;

        isGameOver = false;
    }

    // Update is called once per frame
    void Update()
    {
        PauseGame();

        if (isGameOver)
        {
            GameOver();
        }

        if (isBossDefeated)
        {
            BossDefeated();
        }
    }

    public void BossDefeated()
    {
        SceneManager.LoadScene("Credits");
    }

    public void GameOver()
    {
        StartCoroutine(GameOverCO());
    }

    IEnumerator GameOverCO()
    {
        gameOver.gameObject.SetActive(true);

        yield return new WaitForSeconds(waitToLoadScene);

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    void PauseGame()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && !isPaused)
        {
            Cursor.visible = true;

            Time.timeScale = 0;

            isPaused = true;

            pauseScreen.SetActive(true);

            AudioManager.instance.footSteps.Stop();
            AudioManager.instance.BgmPause(1);
        }

        else if (Input.GetKeyDown(KeyCode.Escape) && isPaused)
        {
            Cursor.visible = false;

            Time.timeScale = 1;

            isPaused = false;

            pauseScreen.SetActive(false);

            AudioManager.instance.BgmUnpause(1);
            AudioManager.instance.footSteps.Play();
        }
    }

    public void MainMenu()
    {
        AudioManager.instance.BgmPause(1);
        SceneManager.LoadScene("MainMenu");
    }

}
