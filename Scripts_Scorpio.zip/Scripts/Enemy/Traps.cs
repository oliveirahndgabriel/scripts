using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Traps : MonoBehaviour
{
    [SerializeField] float waitCounter, waitRate;

    [SerializeField] int damage;

    [SerializeField] bool alreadyAttack, damageTrap;

    PlayerHealth playerHealth;

    private void Awake()
    {
        playerHealth = FindObjectOfType<PlayerHealth>().GetComponent<PlayerHealth>();
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            if (!alreadyAttack && damageTrap)
            {
                if (waitCounter <= 0)
                {
                    alreadyAttack = true;

                    DamageTrap();
                }
            }
        }
        waitCounter -= Time.deltaTime;
    }

    void DamageTrap()
    {
        playerHealth.TakeDamage(damage);

        alreadyAttack = false;

        waitCounter = waitRate;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireCube(transform.position, gameObject.transform.localScale);
    }
}
