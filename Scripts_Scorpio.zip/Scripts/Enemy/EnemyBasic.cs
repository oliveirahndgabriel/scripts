using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyBasic : MonoBehaviour
{
    public EnemyScriptable enemyScript;

    NavMeshAgent navAgent;

    [SerializeField] bool isChasing, canWalk, alreadyAttk;

    Vector3 target, startPoint;

    float targetDistance;

    PlayerController playerTarget;

    private void Awake()
    {
        navAgent = GetComponent<NavMeshAgent>();

        playerTarget = GameObject.Find("Player").GetComponent<PlayerController>();
    }

    // Start is called before the first frame update
    void Start()
    {
        startPoint = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        target = playerTarget.transform.position;

        targetDistance = Vector3.Distance(transform.position, target);

        if (canWalk)
        {
            EnemyMovementChase();
        }

        DamageCollider();
    }

    void EnemyMovementChase()
    {
        if (targetDistance < enemyScript.distanceToChase)
        {
            isChasing = true;

            if (isChasing)
            {
                navAgent.destination = target;
            }
        }
 
    }

    void DamageCollider()
    {
        Collider[] otherCollision;
        otherCollision = Physics.OverlapSphere(transform.position, enemyScript.raio);

        foreach (Collider actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Player")
            {
                if (!alreadyAttk)
                {
                    alreadyAttk = true;

                    actualOther.gameObject.GetComponent<PlayerHealth>().TakeDamage(enemyScript.damage);
                    navAgent.isStopped = true;

                    StartCoroutine(FollowCounter());
                }
               
            }
        }
    }

    IEnumerator FollowCounter()
    {
        yield return new WaitForSeconds(5);
        
        navAgent.isStopped = false;

        alreadyAttk = false;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, enemyScript.raio);
    }
}
