using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Enemy", menuName = "EnemyType")]
public class EnemyScriptable : ScriptableObject
{
    public new string name;

    public int damage;

    [Header("Health Enemy")]
    public int maxHealth;
    
    [Header("Chase Enemy")]
    public float distanceToChase;
    public float raio;

    [Header("Turret Enemy")]
    public bool shootFollow;
    public bool shootRotate;
    public float distanceToShoot, shootRate, shootCounter;
}
