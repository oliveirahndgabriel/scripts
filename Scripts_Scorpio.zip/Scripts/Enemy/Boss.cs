using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : MonoBehaviour
{
    [SerializeField] bool fourShoot, eightShoot;

    [SerializeField] float shootRate, randomRate, moveRate, powerRate;
    float shootCounter, randomCounter, moveCounter, powerCounter;
    float spinSpeed, moveSpeed;

    int bossState, powerUpPick;

    [SerializeField] Transform enemyShootPoint, esp2, esp3, esp4, esp5, esp6, esp7, esp8;

    [SerializeField] GameObject enemyBullet;
    [SerializeField] GameObject[] powerUp;

    EnemyHealth enemyHealth;

    private void Awake()
    {
        bossState = 0;

        enemyHealth = GetComponent<EnemyHealth>();
    }
    
    // Update is called once per frame
    void Update()
    {
        ShootType();

        MoveAround();

        RandomRoutine();

        ShootRate();
    }

    void MoveAround()
    {
        transform.RotateAround(transform.position, transform.up, Time.deltaTime * spinSpeed);

        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    }

    void RandomRoutine()
    {
        if (randomCounter <= 0)
        {
            bossState = Random.Range(0, 10);
            randomCounter = randomRate;
            RandomState();
        }

        randomCounter -= Time.deltaTime;

        if (moveCounter <= 0)
        {
            spinSpeed = Random.Range(90, 180);
            moveSpeed = Random.Range(5, 10);

            moveCounter = moveRate;
        }

        moveCounter -= Time.deltaTime;

        if (powerCounter <= 0)
        {
            powerUpPick = Random.Range(0,1);

            Instantiate(powerUp[powerUpPick], transform.position, transform.rotation);

            powerCounter = powerRate;
        }

        powerCounter -= Time.deltaTime;
    }


    void RandomState()
    {
        if (bossState < 7)
        {
            fourShoot = true;
            eightShoot = false;
        }
        if (bossState >= 7 && bossState <= 10)
        {
            fourShoot = false;
            eightShoot = true;
        }
    }

    void ShootType()
    {
        if (fourShoot)
        {
            if (shootCounter <= 0)
            {
                Invoke("FourBulletFire", 0.5f);
                shootCounter = shootRate;
            }

            shootCounter -= Time.deltaTime;
        }

        if (eightShoot)
        {
            if (shootCounter <= 0)
            {
                Invoke("EightBulletFire", 0.5f);
                shootCounter = shootRate;
            }

            shootCounter -= Time.deltaTime;
        }
    }

    void FourBulletFire()
    {
        Instantiate(enemyBullet, enemyShootPoint.position, enemyShootPoint.transform.rotation);
        Instantiate(enemyBullet, esp2.position, esp2.transform.rotation);
        Instantiate(enemyBullet, esp3.position, esp3.transform.rotation);
        Instantiate(enemyBullet, esp4.position, esp4.transform.rotation);
    }

    void EightBulletFire()
    {
        FourBulletFire();
        Instantiate(enemyBullet, esp5.position, esp5.transform.rotation);
        Instantiate(enemyBullet, esp6.position, esp6.transform.rotation);
        Instantiate(enemyBullet, esp7.position, esp7.transform.rotation);
        Instantiate(enemyBullet, esp8.position, esp8.transform.rotation);
    }

    void ShootRate()
    {
        if(enemyHealth.currentHealth <= 60)
        {
            shootRate = 0.4f;
        }
        if (enemyHealth.currentHealth <= 40)
        {
            shootRate = 0.3f;
        }
        if (enemyHealth.currentHealth <= 30)
        {
            shootRate = 0.2f;
        }
        if (enemyHealth.currentHealth <= 20)
        {
            shootRate = 0.1f;
        }
    }


}


