using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Invoker : MonoBehaviour
{
    public EnemyScriptable enemyScript;

    [SerializeField] float spawnRate, spawnCounter;

    [SerializeField] Transform spawn1, spawn2, spawn3;
    [SerializeField] GameObject enemyPrefab;
    PlayerController playerTarget;
    bool isSpawned;

    Vector3 target;
    float targetDistance;

    private void Awake()
    {
        playerTarget = GameObject.Find("Player").GetComponent<PlayerController>();
    }

    private void FixedUpdate()
    {
        target = playerTarget.transform.position;

        targetDistance = Vector3.Distance(transform.position, target);

        if (targetDistance < enemyScript.distanceToShoot)
        {
            if(spawnCounter < 0)
            {
                Spawn();

                //isSpawned = true;
            }
        }

        spawnCounter -= Time.deltaTime;
    }

    void Spawn()
    {
        Instantiate(enemyPrefab, spawn1.position, spawn1.rotation);
        Instantiate(enemyPrefab, spawn2.position, spawn2.rotation);
        Instantiate(enemyPrefab, spawn3.position, spawn3.rotation);

        spawnCounter = spawnRate;

    }

}
