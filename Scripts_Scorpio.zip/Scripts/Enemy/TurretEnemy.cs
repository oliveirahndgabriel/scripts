using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretEnemy : MonoBehaviour
{
    public EnemyScriptable enemyScript;

    Vector3 target;
    [SerializeField] Transform enemyShootPoint, esp2, esp3, esp4;

    float targetDistance;

    [SerializeField] GameObject enemyBullet;
    PlayerController playerTarget;

    private void Awake()
    {
        playerTarget = GameObject.Find("Player").GetComponent<PlayerController>();
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        target = playerTarget.transform.position;

        targetDistance = Vector3.Distance(transform.position, target);

        ShootType();
    }

    void ShootType()
    {
        if (targetDistance < enemyScript.distanceToShoot)
        {
            if (enemyScript.shootFollow)
            {
                transform.LookAt(target);

                if(enemyScript.shootCounter <= 0)
                {
                    Invoke("SingleBulletFire", 0.5f);
                    enemyScript.shootCounter = enemyScript.shootRate;
                }

                enemyScript.shootCounter -= Time.deltaTime;
            }

            if (enemyScript.shootRotate)
            {
                transform.RotateAround(transform.position, transform.up, Time.deltaTime * 90f);

                if (enemyScript.shootCounter <= 0)
                {
                    Invoke("FourBulletFire", 0.5f);
                    enemyScript.shootCounter = enemyScript.shootRate;
                }

                enemyScript.shootCounter -= Time.deltaTime;
            }

        }
    }

    void SingleBulletFire()
    {
        Instantiate(enemyBullet, enemyShootPoint.position, enemyShootPoint.transform.rotation);
    }

    void FourBulletFire()
    {
        Instantiate(enemyBullet, enemyShootPoint.position, enemyShootPoint.transform.rotation);
        Instantiate(enemyBullet, esp2.position, esp2.transform.rotation);
        Instantiate(enemyBullet, esp3.position, esp3.transform.rotation);
        Instantiate(enemyBullet, esp4.position, esp4.transform.rotation);
    }
}
