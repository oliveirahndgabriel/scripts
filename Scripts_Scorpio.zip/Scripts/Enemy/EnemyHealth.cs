using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public EnemyScriptable enemyScript;

    public int currentHealth;

    [SerializeField] GameObject[] pickUps;

    [SerializeField] bool isBoss;

    UIManager uiManager;

    private void Awake()
    {
        if (isBoss)
        {
            uiManager = FindObjectOfType<UIManager>().GetComponent<UIManager>();
            uiManager.bossHealthSlider.maxValue = enemyScript.maxHealth;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = enemyScript.maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        if (currentHealth <= 0)
        {
            Debug.Log(gameObject.name + " is dead");

            DropItem();

            Destroy(gameObject);
        }

        if (isBoss)
        {
            BossHealth();

            if(currentHealth <= 0)
            {
                GameManager.instance.isBossDefeated = true;
            }
        }
    }

    public void TakeDamage(int damageTaken)
    {
        currentHealth -= damageTaken;
    }

    void DropItem()
    {
        int rando = Random.Range(0, 5);
        int pickRando = Random.Range(0,2);

        if(rando == 0 || rando == 5)
        {
            Instantiate(pickUps[pickRando], transform.position, transform.rotation);
        }
    }

    void BossHealth()
    {
        uiManager.bossHealthSlider.value = currentHealth;
    }
}
