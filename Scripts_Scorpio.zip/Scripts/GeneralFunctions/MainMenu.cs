using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    [SerializeField] string mainMenu, credits, startGame, tutorial;

    [SerializeField] GameObject configMenu;
    [SerializeField] GameObject bgGreen, bgRed;
        
    bool endGame;

    private void FixedUpdate()
    {
        ChangeBG();
    }

    public void StartGame()
    {
        SceneManager.LoadScene(tutorial);
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Quit game");
    }

    public void Config()
    {
        Debug.Log("Config Settings");
        configMenu.gameObject.SetActive(true);
    }

    public void Back()
    {
        configMenu.gameObject.SetActive(false);
    }

    public void EndCredits()
    {
        endGame = true;
        SceneManager.LoadScene(mainMenu);
    }

    public void Credits()
    {
        SceneManager.LoadScene(credits);
    }

    public void Tutorial()
    {
        SceneManager.LoadScene(startGame);
    }

    void ChangeBG()
    {
        if (endGame)
        {
            bgRed.SetActive(false);
            bgGreen.SetActive(true);
        }
    }
}
