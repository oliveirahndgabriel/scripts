using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseScreen : MonoBehaviour
{
    [SerializeField] string mainMenu;

    [SerializeField] GameObject pauseScreen, exitMenu, configMenu;

    public void ResumeGame()
    {
        pauseScreen.SetActive(false);
        exitMenu.SetActive(false);
        configMenu.SetActive(false);
    }

    public void ConfigInGame()
    {
        configMenu.SetActive(true);
    }

    public void ExitInGame()
    {
        exitMenu.SetActive(true);
    }

    public void ExitToDesktop()
    {
        Application.Quit();
    }

    public void ExitToMenu()
    {
        SceneManager.LoadScene(mainMenu);

        Time.timeScale = 1f;
    }
}
