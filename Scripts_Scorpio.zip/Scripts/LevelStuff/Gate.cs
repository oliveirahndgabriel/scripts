using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gate : MonoBehaviour
{
    Animator gateAnim;

    [SerializeField] bool useCard, isBlue, isRed;

    PlayerController playerControl;

    [SerializeField] GameObject door;

    [SerializeField] Collider rigiDoor;


    private void Awake()
    {
        playerControl = FindObjectOfType<PlayerController>().GetComponent<PlayerController>();

        gateAnim = GetComponent<Animator>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            if (useCard)
            {
                if (isBlue && playerControl.blueCard)
                {
                    UIManager.instance.blueCard.SetActive(false);
                    GateUp();
                    DestroyDoor();
                }

                if (isRed && playerControl.redCard)
                {
                    UIManager.instance.redCard.SetActive(false);
                    GateUp();
                    DestroyDoor();
                }
            }
        }
    }

    public void GateUp()
    {
        gateAnim.SetTrigger("Gate_Up");
    }

    void DestroyDoor()
    {
        Destroy(door, 2f);
        Destroy(rigiDoor, 0.3f);
    }

}
