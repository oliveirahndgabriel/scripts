using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Checkpoint : MonoBehaviour
{
    [SerializeField] string cpName;
    PlayerController playerControl;

    private void Awake()
    {
        playerControl = FindObjectOfType<PlayerController>().GetComponent<PlayerController>();
    }

    // Start is called before the first frame update
    void Start()
    {
        if (PlayerPrefs.HasKey(SceneManager.GetActiveScene().name + "_cp"))
        {
            if (PlayerPrefs.GetString(SceneManager.GetActiveScene().name + "_cp") == cpName)
            {
                playerControl.transform.position = transform.position;

                //project settings physics and activated auto sync transforms
                //line of code that do this above
                Physics.SyncTransforms();

                Debug.Log("Player has Spawned at " + cpName);
            }
        }
    }

    private void FixedUpdate()
    {
        ResetCheckpoint();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            PlayerPrefs.SetString(SceneManager.GetActiveScene().name + "_cp", cpName);

            Debug.Log("Player has enable " + cpName);
        }
    }

    void ResetCheckpoint()
    {
        if (Input.GetKeyDown(KeyCode.L))
        {
            PlayerPrefs.SetString(SceneManager.GetActiveScene().name + "_cp", "");
        }
    }
}
