using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelExit : MonoBehaviour
{
    [SerializeField] string nextLevel;

    [SerializeField] float waitToLoadLevel;

    [SerializeField] LayerMask seilaMask;

    private void FixedUpdate()
    {
        Collider[] otherCollision;
        otherCollision = Physics.OverlapBox(gameObject.transform.position, gameObject.transform.lossyScale, Quaternion.identity, seilaMask);

        foreach (Collider actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Player")
            {
                GameManager.instance.levelEnding = true;

                StartCoroutine(LoadingLevel());

                AudioManager.instance.BgmStop(1);
            }
        }
    }

    IEnumerator LoadingLevel()
    {
        PlayerPrefs.SetString(nextLevel + "_cp", "");

        yield return new WaitForSeconds(waitToLoadLevel);

        SceneManager.LoadScene(nextLevel);

        GameManager.instance.levelEnding = false;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireCube(transform.position, gameObject.transform.lossyScale);
    }
}
