using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreditsManager : MonoBehaviour
{
    [SerializeField] float skipCounter, skipRate;

    MainMenu menu;

    [SerializeField] bool isCredits;

    private void Awake()
    {
        menu = FindObjectOfType<MainMenu>().GetComponent<MainMenu>();  
    }

    private void Start()
    {
        skipCounter = skipRate;
    }

    private void FixedUpdate()
    {
        if (isCredits)
        {
            transform.Translate(Vector2.up * 5 * Time.deltaTime);

            if (skipCounter <= 0)
            {
                menu.EndCredits();
            }

            skipCounter -= Time.fixedDeltaTime;
        }
        else
        {
            if (skipCounter <= 0)
            {
                menu.Tutorial();
            }

            skipCounter -= Time.fixedDeltaTime;
        }
        
    }
}
