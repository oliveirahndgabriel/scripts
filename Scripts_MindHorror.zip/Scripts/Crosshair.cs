﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Crosshair : MonoBehaviour
{
    RectTransform reticle;

    float currentSize;
    float maxSize = 95;
    float minSize = 45;
    float aimSpeed = 3f;

    bool isMoving;

    private void Awake()
    {
        reticle = GetComponent<RectTransform>();
    }

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 cursorPos = PlayerController.instance.mousePosition;
        transform.position = cursorPos;

        isMoving = PlayerShoot.instance.isAiming;

        CrosshairUpdate();
    }

    void CrosshairUpdate()
    {
        if (isMoving)
        {
            currentSize = Mathf.Lerp(currentSize, minSize, Time.deltaTime * aimSpeed);
        }
        else
        {
            currentSize = Mathf.Lerp(currentSize, maxSize, Time.deltaTime * aimSpeed);
        }

        reticle.sizeDelta = new Vector2(currentSize, currentSize);

    }
}
