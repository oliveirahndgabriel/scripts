using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehaviour : MonoBehaviour
{
    Rigidbody2D bulletRB;
    [SerializeField] float bulletSpeed = 5f;


    private void Awake()
    {
        bulletRB = GetComponent<Rigidbody2D>();
    }

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
    }

    private void FixedUpdate()
    {
        BulletMovement();

        OutOfBoundry();
    }

    void BulletMovement()
    {
        // transform.position = Vector2.MoveTowards(transform.position, target, 5f * Time.deltaTime);

        //if(PlayerShoot.instance.isAiming == true)
        {
            bulletRB.AddForce(transform.right * bulletSpeed * Time.deltaTime, ForceMode2D.Impulse);
        }
        /*else if(PlayerShoot.instance.isAiming == false)
        {
            //taxa de erro no lancameto do tiro

            bulletRB.AddForce((transform.right * bulletError) * bulletSpeed * Time.deltaTime, ForceMode2D.Impulse);
        }*/
    }

    void OutOfBoundry()
    {
        float outDistance = 30f;

        if (Vector2.Distance(transform.position, PlayerController.instance.transform.position) > outDistance)
        {
            Destroy(this.gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Enemy" || other.tag == "Solid" || other.tag == "Object")
        {
            Destroy(this.gameObject);
        }
    }
}
