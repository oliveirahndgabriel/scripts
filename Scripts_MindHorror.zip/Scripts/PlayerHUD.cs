﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHUD : MonoBehaviour
{
    [SerializeField] Text ammoCount;
    [SerializeField] Slider sliderHealth;

    float playerCurrentAmmo, playerMaxAmmo;
    float playerCurrentHealth, playerMaxHealth;

    // Start is called before the first frame update
    void Start()
    {
        ammoCount.text = "Ammo: " + playerCurrentAmmo + " / " + playerMaxAmmo;
    }

    // Update is called once per frame
    void Update()
    {
        playerCurrentAmmo = PlayerShoot.instance.currentAmmo;
        playerMaxAmmo = PlayerShoot.instance.maxAmmo;

        ammoCount.text = "Ammo: " + playerCurrentAmmo + " / " + playerMaxAmmo;

        playerCurrentHealth = PlayerHealth.instance.currentHealth;
        playerMaxHealth = PlayerHealth.instance.maxHealth;

        sliderHealth.value = playerCurrentHealth / playerMaxHealth;

    }
}
