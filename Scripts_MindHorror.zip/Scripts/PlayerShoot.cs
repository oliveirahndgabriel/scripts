﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour
{
    public static PlayerShoot instance;

    [SerializeField] GameObject bulletPrefab;
    public bool isAiming;
    Transform shootPoint;
    float bulletError;

    public int maxAmmo = 10;
    public int currentAmmo;

    float nextReload, reloadRate = 3.5f;
    bool isReloading;
    bool loaded;

    //int ammoInventory = 0;
    //int bulletAmmo = 7;

    private void Awake()
    {
        instance = this;

        shootPoint = GetComponentInChildren<Transform>();
    }

    private void Start()
    {
        currentAmmo = maxAmmo;
        nextReload = reloadRate;
        loaded = true;
    }

    // Update is called once per frame
    void Update()
    {
        BulletShoot();

        StartReload();

        bulletError = Random.Range(-4.5f, 4.5f);
    }

    void BulletShoot()
    {
        //shooting
        if (Input.GetKey(KeyCode.Mouse1))
        {
            isAiming = true;

            if (isAiming == true)
            {
                if (Input.GetKeyDown(KeyCode.Mouse0) && currentAmmo > 0 && !isReloading)
                {
                    BulletAmmo();

                    Instantiate(bulletPrefab, shootPoint.transform.position, shootPoint.transform.rotation);
                }
            }
        }
        else if (isAiming == false && Input.GetKeyDown(KeyCode.Mouse0) && currentAmmo > 0 && !isReloading)
        {
            BulletAmmo();

            Instantiate(bulletPrefab, shootPoint.transform.position, shootPoint.transform.rotation * Quaternion.Euler(0f, 0f, bulletError));
        }
        else if (Input.GetKeyUp(KeyCode.Mouse1))
        {
            isAiming = false;
        }
    }

    void BulletAmmo()
    {
        currentAmmo--;
        //maxAmmo--;

        loaded = false;
    }

    void StartReload()
    {
        if(isReloading == false && Input.GetKeyDown(KeyCode.R) && loaded == false)
        {
            isReloading = true;

            print("Reloading!");

        }

        if (isReloading)
        {
            nextReload -= Time.deltaTime;

            Reload();
        }
    }

    void Reload()
    {
        if (nextReload <= 0)
        {
            currentAmmo = maxAmmo;

            //int maxToLoad = 6;
            //bool haveAmmo = false;
            /*
            if (currentAmmo < maxAmmo)
            {
                
            }
            else
            {
                Debug.Log("Without Ammo");
            }*/

            nextReload = reloadRate;
            loaded = true;
            isReloading = false;

            print("Loaded!");
        }
    }
}
