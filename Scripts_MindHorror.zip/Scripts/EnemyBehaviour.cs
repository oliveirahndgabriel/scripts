using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBehaviour : MonoBehaviour
{
    float nearPlayer;
    [SerializeField] float distanceToAttack = 7f;
    float nextAttack, attackRate = 3f;

    float maxEnemyHealth = 100;
    [SerializeField] float currentEnemyHealth;

    // Start is called before the first frame update
    void Start()
    {
        currentEnemyHealth = maxEnemyHealth;
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    private void FixedUpdate()
    {
        nearPlayer = Vector2.Distance(transform.position, PlayerController.instance.transform.position);
        nextAttack -= Time.deltaTime;

        if (nearPlayer < distanceToAttack)
        {
            distanceToAttack = 8.5f;
            transform.position = Vector2.MoveTowards(transform.position, PlayerController.instance.transform.position, 1.8f * Time.deltaTime);
        }
        else
        {
            distanceToAttack = 7f;
        }
    }

    void EnemyTakeDamage(float playerDamage)
    {
        currentEnemyHealth -= playerDamage;

        if(currentEnemyHealth <= 0f)
        {
            print(gameObject.name + " was killed");
            Destroy(this.gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Bullet")
        {
            print("enemy take damage");
            EnemyTakeDamage(25);
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            if (nextAttack <= 0)
            {
                nextAttack = attackRate;
                PlayerHealth.instance.PlayerTakeDamage(32);
            }
        }
    }
}
