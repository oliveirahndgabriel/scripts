using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public static PlayerController instance;
    Rigidbody2D playerRB;

    GameObject playerSprite;

    float horizontalInput, verticalInput;
    bool isRunning = false;
    float moveSpeed = 2.8f;

    public Vector2 mousePosition;

    bool cantMove; 

    private void Awake()
    {
        instance = this;

        playerRB = GetComponent<Rigidbody2D>();
        playerSprite = GameObject.FindGameObjectWithTag("Sprite");
        
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        MovementInput();

        cantMove = PlayerShoot.instance.isAiming;

        SpriteFix();
    }

    private void FixedUpdate()
    {
        MovementUpdate();

        Vector2 lookDirection = mousePosition - playerRB.position;
        float angle = Mathf.Atan2(lookDirection.y, lookDirection.x) * Mathf.Rad2Deg;
        playerRB.rotation = angle;
    }

    void MovementInput()
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");
        verticalInput = Input.GetAxisRaw("Vertical");

        isRunning = Input.GetKey(KeyCode.LeftShift);

        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }

    void MovementUpdate()
    {
        if (cantMove == false)
        {
            playerRB.velocity = new Vector2(moveSpeed * horizontalInput, moveSpeed * verticalInput);
        }
        else if(cantMove == true)
        {
            playerRB.velocity = Vector2.zero;
        }

        if (isRunning)
        {
            moveSpeed = 3.8f;
        }
        else
        {
            isRunning = false;
            moveSpeed = 2.8f;
        }
    }

    void SpriteFix()
    {
        bool isFaceRight = (mousePosition.x - transform.position.x) > 0;



        if (!isFaceRight)
        {
            playerSprite.transform.rotation = Quaternion.Euler(0, 180f, 0);
        }
        else
        {
            playerSprite.transform.rotation = Quaternion.Euler(0, 0f, 0);
        }
    }
}
