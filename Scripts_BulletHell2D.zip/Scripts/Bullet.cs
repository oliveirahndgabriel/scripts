using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] PlayerPowerScriptable damageScript;

    [SerializeField] float bulletSpeed, destroyCounter, destroyRate;
    //[SerializeField] GameObject particleSplash;

    private void Start()
    {
        destroyCounter = destroyRate;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector2.up * bulletSpeed * Time.deltaTime);

        AutoDestroy();
        DamageCollider();
    }

    void DamageCollider()
    {
        Collider2D[] otherCollision;
        otherCollision = Physics2D.OverlapCircleAll(transform.position, damageScript.raio);

        foreach (Collider2D actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Enemy")
            {
                Debug.Log("Damage to " + actualOther.name);
                actualOther.gameObject.GetComponent<EnemyHealth>().EnemyTakeDamage(damageScript.damage);
            }
        }
    }

    void AutoDestroy()
    {
        if (destroyCounter <= 0)
        {
            Destroy(gameObject);
        }

        destroyCounter -= Time.deltaTime;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, damageScript.raio);
    }

}
