using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public static PlayerController instance;

    Rigidbody2D playerRB;
    Animator playerAnim;

    [Header("Player Movement")]
    [Space]
    float horizontalInput, verticalInput;
    [SerializeField] float moveSpeed;

    bool isFacingRight = true;


    private void Awake()
    {
        instance = this;

        playerRB = GetComponent<Rigidbody2D>();
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        MovementInput();
    }

    private void FixedUpdate()
    {
        MovementUpdate();
    }

    void MovementInput()
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");
        verticalInput = Input.GetAxisRaw("Vertical");
    }

    void MovementUpdate()
    {
        playerRB.velocity = new Vector2(horizontalInput * moveSpeed, verticalInput * moveSpeed);

        RotatePlayer();
    }

    void RotatePlayer()
    {
        if (horizontalInput > 0 && !isFacingRight)
        {
            Facing();
        }
        else if (horizontalInput < 0 && isFacingRight)
        {
            Facing();
        }
    }

    void Facing()
    {
        isFacingRight = !isFacingRight;
        transform.Rotate(0f, 180f, 0f);
    }
}

