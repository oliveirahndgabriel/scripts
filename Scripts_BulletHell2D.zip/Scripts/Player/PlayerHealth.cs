using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] float currentHealth, maxHealth = 100f;

    public bool isDead, isImmortal;
    float immortalCounter, immortalRate = 0.8f;

    UiManager uiManager;

    private void Awake()
    {
        uiManager = FindObjectOfType<UiManager>().GetComponent<UiManager>();
    }

    // Start is called before the first frame update
    void Start()
    {
        isDead = false;

        currentHealth = maxHealth;
        immortalCounter = immortalRate;

        uiManager.healthSlider.maxValue = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        uiManager.healthSlider.value = currentHealth;
    }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
       // isImmortal = true;
        //IsImmortal();

        if(currentHealth <= 0)
        {
            isDead = true;

            Debug.Log(gameObject + " is dead");

            Destroy(this.gameObject);
        }
    }

    void IsImmortal()
    {
        if (isImmortal)
        {
            //immortalGlobe.gameObject.SetActive(true);

            if (immortalCounter <= 0)
            {
                immortalCounter = immortalRate;
                isImmortal = false;
                //immortalGlobe.gameObject.SetActive(false);
                Debug.Log("is imortal");
            }

            immortalCounter -= Time.deltaTime;
        }
    }
}
