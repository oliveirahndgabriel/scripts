using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    [SerializeField] PlayerPowerScriptable powerScript1;
    [SerializeField] PlayerPowerScriptable powerScript2;/*
    [SerializeField] PlayerPowerScriptable powerScript3;
    [SerializeField] PlayerPowerScriptable powerScript4;*/

    float attackCounter;
    [SerializeField] float attackRate = 0.8f;

    [SerializeField] float playerDamage;

    [SerializeField] Transform attackPoint;
    [SerializeField] float attackRange;
    [SerializeField] LayerMask enemyLayer;

    [SerializeField] GameObject fireBall;

    [SerializeField] bool isAuto;

    LookAtPoint lookPoint;

    private void Awake()
    {
        lookPoint = FindObjectOfType<LookAtPoint>().GetComponent<LookAtPoint>();
    }

    // Start is called before the first frame update
    void Start()
    {
        attackCounter = attackRate;
    }

    // Update is called once per frame
    void Update()
    {
        MeleeAttack();
        Attack1();
        Attack2();
    }

    void MeleeAttack()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            if (attackCounter <= 0)
            {
                Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayer);

                foreach (Collider2D enemy in hitEnemies)
                {
                    Debug.Log(enemy.name + " was hit");
                    enemy.GetComponent<EnemyHealth>().EnemyTakeDamage(playerDamage);

                    attackCounter = attackRate;
                }

            }
        }
        attackCounter -= Time.deltaTime;
    }

    void Attack1()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            if(powerScript1.shootCounter <= 0)
            {
                Instantiate(fireBall, lookPoint.transform.position, lookPoint.transform.rotation);

                powerScript1.shootCounter = powerScript1.shootRate;
            }
        }

        powerScript1.shootCounter -= Time.deltaTime;
    }

    void Attack2()
    {
        if (isAuto)
        {
            InvokeRepeating("SpreadAround", powerScript2.shootCounter, powerScript2.shootRate);
            
        }
        else if (!isAuto)
        {
            if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                SpreadAround();
            }
        }

    }

    void SpreadAround()
    {
        if (powerScript2.shootCounter <= 0)
        {
            Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, powerScript2.raio, enemyLayer);

            foreach (Collider2D enemy in hitEnemies)
            {
                Debug.Log(enemy.name + " was hit");
                enemy.GetComponent<EnemyHealth>().EnemyTakeDamage(powerScript2.damage);

                powerScript2.shootCounter = powerScript2.shootRate;
            }
        }
        powerScript2.shootCounter -= Time.deltaTime;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, powerScript2.raio);
    }
}
