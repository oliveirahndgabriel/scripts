using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Power", menuName = "PowerType")]
public class PlayerPowerScriptable : ScriptableObject
{
    public new string name;

    public int damage;
    public float raio;
    public float distanceToChase;

    public float distanceToShoot, shootRate, shootCounter;

    public bool shootFollow;
    public bool shootRotate;

}
