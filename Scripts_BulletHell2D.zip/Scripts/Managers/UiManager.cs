using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UiManager : MonoBehaviour
{
    public static UiManager instance;

    public Slider healthSlider /*bossHealthSlider*/;

    [SerializeField] Image blackscreen;

    public Text pointsText;
    //float fadeSpeed = 1.5f;

    private void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void FixedUpdate()
    {
        FadeBlackscreen();
    }

    void FadeBlackscreen()
    {
        /*if (!GameManager.instance.levelEnding)
        {
            blackscreen.color = new Color(blackscreen.color.r, blackscreen.color.g, blackscreen.color.b, Mathf.MoveTowards(blackscreen.color.a, 0f, fadeSpeed * Time.deltaTime));
        }
        else
        {
            blackscreen.color = new Color(blackscreen.color.r, blackscreen.color.g, blackscreen.color.b, Mathf.MoveTowards(blackscreen.color.a, 1f, fadeSpeed * Time.deltaTime));
        }*/
    }
}
