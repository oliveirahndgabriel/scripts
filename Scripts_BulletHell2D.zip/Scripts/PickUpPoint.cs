using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUpPoint : MonoBehaviour
{
    [SerializeField] float raio = 0.15f;
    [SerializeField] int pointAmount;

    // Update is called once per frame
    void Update()
    {
        DetectCollisions();
    }

    void DetectCollisions()
    {
        Collider2D[] otherCollision;
        otherCollision = Physics2D.OverlapCircleAll(transform.position, raio);

        foreach (Collider2D actualOther in otherCollision)
        {
            if (actualOther.gameObject.tag == "Player")
            {
                FindObjectOfType<PointsHandler>().PointsCounter(pointAmount); 

                Debug.Log("Crystal collected");

                Destroy(gameObject);
            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, raio);
    }
}
