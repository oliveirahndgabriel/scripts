using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointsHandler : MonoBehaviour
{
    int pointCounter;

    UiManager uiManager;

    private void Awake()
    {
        uiManager = FindObjectOfType<UiManager>().GetComponent<UiManager>();
    }

    
    private void FixedUpdate()
    {
    }

    public void PointsCounter(int point)
    {
        pointCounter += point;

        uiManager.pointsText.text = pointCounter.ToString();

    }
}
